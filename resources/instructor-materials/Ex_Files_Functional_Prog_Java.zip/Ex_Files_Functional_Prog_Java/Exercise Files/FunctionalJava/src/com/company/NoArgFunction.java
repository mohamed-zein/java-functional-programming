package com.company;

public interface NoArgFunction<R> {
    R apply();
}
